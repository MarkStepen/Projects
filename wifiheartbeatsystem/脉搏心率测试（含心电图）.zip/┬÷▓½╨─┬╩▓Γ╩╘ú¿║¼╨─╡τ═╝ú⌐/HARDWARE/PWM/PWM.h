#ifndef _PWM_H
#define _PWM_H
#include "sys.h"
#include "adc.h"
#define true 1
#define false 0

void TIM3_PWM_Init(void);
#endif

