#ifndef _TIMER_H
#define _TIMER_H

#include "sys.h"
#include "adc.h"

#define true 1
#define false 0

void TIM3_Int_Init(u16 arr,u16 psc);
void TIM1_Int_Init(u16 arr,u16 psc);

#endif
